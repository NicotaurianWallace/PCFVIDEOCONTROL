# VideoUploadControl
 A pcf control to upload video files as attachments(Notes) with a live preview functionality.
